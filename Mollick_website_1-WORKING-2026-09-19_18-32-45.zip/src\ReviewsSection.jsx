import { memo, useEffect, useRef, useState } from "react";
import "./ReviewsSection.css";

const reviews = [
  {
    id: 1,
    projectEn: "Bright Health",
    projectBn: "ব্রাইট হেলথ",
    nameEn: "Bright Health",
    nameBn: "ব্রাইট হেলথ",
    roleEn: "Project feedback",
    roleBn: "প্রজেক্ট ফিডব্যাক",
    companyEn: "Bright Health",
    companyBn: "ব্রাইট হেলথ",
    logo: "bright-health.png",
    quoteEn: "The team understood our digital healthcare requirements and shaped them into a clear, practical product. Communication was responsive, and the project was handled carefully from planning through implementation.",
    quoteBn: "আমাদের ডিজিটাল হেলথকেয়ার প্রয়োজনগুলো টিমটি ভালোভাবে বুঝে একটি পরিষ্কার ও ব্যবহারিক প্রোডাক্টে রূপ দিয়েছে। পরিকল্পনা থেকে বাস্তবায়ন পর্যন্ত যোগাযোগ ছিল দ্রুত এবং কাজের প্রতিটি ধাপ যত্নের সাথে পরিচালনা করা হয়েছে।",
    initials: "BH",
  },
  {
    id: 2,
    projectEn: "Buniyan Group",
    projectBn: "বুনিয়ান গ্রুপ",
    nameEn: "Buniyan Group",
    nameBn: "বুনিয়ান গ্রুপ",
    roleEn: "Project feedback",
    roleBn: "প্রজেক্ট ফিডব্যাক",
    companyEn: "Buniyan Group",
    companyBn: "বুনিয়ান গ্রুপ",
    logo: "buniyan1.png",
    quoteEn: "Mollick Software Solutions understood our business needs quickly and delivered a clean, organized solution. Their structured communication made the development process straightforward and easy to follow.",
    quoteBn: "Mollick Software Solutions খুব দ্রুত আমাদের ব্যবসার প্রয়োজন বুঝে একটি পরিপাটি ও সুসংগঠিত সমাধান তৈরি করেছে। তাদের পরিকল্পিত যোগাযোগের কারণে পুরো ডেভেলপমেন্ট প্রক্রিয়াটি সহজ ও পরিষ্কার ছিল।",
    initials: "BG",
  },
  {
    id: 3,
    projectEn: "Khedma Tech",
    projectBn: "খেদমা টেক",
    nameEn: "Khedma Tech",
    nameBn: "খেদমা টেক",
    roleEn: "Project feedback",
    roleBn: "প্রজেক্ট ফিডব্যাক",
    companyEn: "Khedma Tech",
    companyBn: "খেদমা টেক",
    logo: "khedma-tech.jpeg",
    quoteEn: "We appreciated the team's structured approach, attention to usability, and willingness to refine important details during development. The final direction matched the goals we had for the platform.",
    quoteBn: "টিমের পরিকল্পিত কাজের ধরণ, ব্যবহারকারীর অভিজ্ঞতার প্রতি গুরুত্ব এবং ডেভেলপমেন্টের সময় প্রয়োজনীয় বিষয়গুলো বারবার পরিমার্জন করার মানসিকতা আমাদের ভালো লেগেছে। প্ল্যাটফর্মটির চূড়ান্ত দিকনির্দেশনা আমাদের লক্ষ্য অনুযায়ী হয়েছে।",
    initials: "KT",
  },
  {
    id: 4,
    projectEn: "Mollick Enterprise",
    projectBn: "মল্লিক এন্টারপ্রাইজ",
    nameEn: "Mollick Enterprise",
    nameBn: "মল্লিক এন্টারপ্রাইজ",
    roleEn: "Project feedback",
    roleBn: "প্রজেক্ট ফিডব্যাক",
    companyEn: "Mollick Enterprise",
    companyBn: "মল্লিক এন্টারপ্রাইজ",
    logo: "Mollick.png",
    quoteEn: "The software was built around real day-to-day business operations, with a strong focus on simplicity, useful reporting, and practical workflows. It has given the business a much clearer digital process.",
    quoteBn: "সফটওয়্যারটি আমাদের দৈনন্দিন ব্যবসায়িক কাজের বাস্তব প্রয়োজনকে কেন্দ্র করে তৈরি করা হয়েছে। সহজ ব্যবহার, প্রয়োজনীয় রিপোর্ট এবং কার্যকর ওয়ার্কফ্লোর কারণে ব্যবসার কাজ এখন অনেক বেশি পরিষ্কারভাবে ডিজিটালভাবে পরিচালনা করা যায়।",
    initials: "ME",
  },
  {
    id: 5,
    projectEn: "Nikahnama",
    projectBn: "নিকাহনামা",
    nameEn: "Nikahnama",
    nameBn: "নিকাহনামা",
    roleEn: "Project feedback",
    roleBn: "প্রজেক্ট ফিডব্যাক",
    companyEn: "Nikahnama",
    companyBn: "নিকাহনামা",
    logo: "Nikahnama.png",
    quoteEn: "The product has been developed with close attention to user experience, privacy, and the needs of its audience. The team has been flexible throughout the project and thoughtful about each important user flow.",
    quoteBn: "প্রোডাক্টটি তৈরি করার সময় ব্যবহারকারীর অভিজ্ঞতা, গোপনীয়তা এবং লক্ষ্য ব্যবহারকারীদের প্রয়োজনকে বিশেষ গুরুত্ব দেওয়া হয়েছে। পুরো প্রজেক্টে টিমটি নমনীয় ছিল এবং প্রতিটি গুরুত্বপূর্ণ ইউজার ফ্লো মনোযোগ দিয়ে তৈরি করেছে।",
    initials: "NK",
  },
  {
    id: 6,
    projectEn: "Opar",
    projectBn: "ওপার",
    nameEn: "Opar",
    nameBn: "ওপার",
    roleEn: "Project feedback",
    roleBn: "প্রজেক্ট ফিডব্যাক",
    companyEn: "Opar",
    companyBn: "ওপার",
    logo: "Opar.png",
    quoteEn: "The team brought the product requirements, interface direction, and technical implementation together in a practical way. Their support during revisions helped us keep the project aligned with the intended experience.",
    quoteBn: "টিমটি প্রোডাক্টের প্রয়োজন, ইন্টারফেসের দিকনির্দেশনা এবং টেকনিক্যাল ইমপ্লিমেন্টেশনকে সুন্দরভাবে একসাথে এনেছে। বিভিন্ন সংশোধনের সময় তাদের সহযোগিতায় প্রজেক্টটি আমাদের কাঙ্ক্ষিত অভিজ্ঞতার সাথে সামঞ্জস্যপূর্ণ রাখা সম্ভব হয়েছে।",
    initials: "OP",
  },
  {
    id: 7,
    projectEn: "JoruriCode",
    projectBn: "জরুরি কোড",
    nameEn: "JoruriCode",
    nameBn: "জরুরি কোড",
    roleEn: "Project feedback",
    roleBn: "প্রজেক্ট ফিডব্যাক",
    companyEn: "JoruriCode",
    companyBn: "জরুরি কোড",
    logo: "JoruriCode.jpeg",
    quoteEn: "JoruriCode required careful thinking around emergency flows, usability, and reliability. The team approached those requirements methodically and kept the experience simple while handling the underlying technical complexity.",
    quoteBn: "JoruriCode প্রজেক্টে জরুরি পরিস্থিতির ফ্লো, সহজ ব্যবহার এবং নির্ভরযোগ্যতা নিয়ে খুব সতর্কভাবে কাজ করা প্রয়োজন ছিল। টিমটি পরিকল্পিতভাবে এসব বিষয় বাস্তবায়ন করেছে এবং ভেতরের টেকনিক্যাল জটিলতা সামলে ব্যবহারকারীর অভিজ্ঞতা সহজ রেখেছে।",
    initials: "JC",
  },
];

function ReviewsSectionComponent({ lang = "en" }) {
  const isBn = lang === "bn";
  const [active, setActive] = useState(0);
  const sectionRef = useRef(null);

  const previous = () => {
    setActive((current) =>
      current === 0 ? reviews.length - 1 : current - 1
    );
  };

  const next = () => {
    setActive((current) =>
      current === reviews.length - 1 ? 0 : current + 1
    );
  };

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return undefined;

    const heading = section.querySelector(".mollick-reviews__heading");
    const card = section.querySelector(".mollick-reviews__card");

    const targets = [heading, card].filter(Boolean);

    targets.forEach((element, index) => {
      element.dataset.reveal = index === 0 ? "text" : "visual";
      if (index === 1) element.dataset.revealDelay = "380";
      element.classList.remove("is-revealed");
    });

    if (!("IntersectionObserver" in window)) {
      targets.forEach((element) =>
        element.classList.add("is-revealed")
      );
      return undefined;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;

          const delay = Number(
            entry.target.dataset.revealDelay || 0
          );

          window.setTimeout(() => {
            entry.target.classList.add("is-revealed");
          }, delay);

          observer.unobserve(entry.target);
        });
      },
      {
        threshold: 0.12,
        rootMargin: "0px 0px -12% 0px",
      }
    );

    targets.forEach((element) => observer.observe(element));

    return () => observer.disconnect();
  }, []);

  const review = reviews[active];

  return (
    <section
      ref={sectionRef}
      className="mollick-reviews"
      id="reviews"
      aria-labelledby="mollick-reviews-title"
    >
      <div className="mollick-reviews__heading">
        <span>
          {isBn ? "ক্লায়েন্ট মতামত" : "Testimonials"}
        </span>

        <h2 id="mollick-reviews-title">
          {isBn ? "রিভিউ" : "Reviews"}
        </h2>

        <p>
          {isBn
            ? "আমাদের সাথে কাজ করার অভিজ্ঞতা সম্পর্কে ক্লায়েন্টদের মতামত।"
            : "Hear directly from the clients we've partnered with on their experience working with our team."}
        </p>
      </div>

      <div className="mollick-reviews__card">
        <button
          className="mollick-reviews__arrow is-left"
          type="button"
          onClick={previous}
          aria-label={isBn ? "আগের রিভিউ" : "Previous review"}
        >
          ‹
        </button>

        <div className="mollick-reviews__brand">
          <img
            className="mollick-reviews__logo"
            src={`${import.meta.env.BASE_URL}${review.logo}`}
            alt={isBn ? review.projectBn : review.projectEn}
            loading="lazy"
            decoding="async"
          />
          <strong>
            {isBn ? review.companyBn : review.companyEn}
          </strong>
        </div>

        <div className="mollick-reviews__divider" />

        <div className="mollick-reviews__content">
          <div className="mollick-reviews__quote-mark">“</div>

          <blockquote>
            {isBn ? review.quoteBn : review.quoteEn}
          </blockquote>

          <div className="mollick-reviews__person">
            <div className="mollick-reviews__avatar">
              {review.initials}
            </div>

            <div>
              <strong>
                {isBn ? review.nameBn : review.nameEn}
              </strong>
              <span>
                {isBn ? review.roleBn : review.roleEn}
              </span>
            </div>
          </div>
        </div>

        <button
          className="mollick-reviews__arrow is-right"
          type="button"
          onClick={next}
          aria-label={isBn ? "পরের রিভিউ" : "Next review"}
        >
          ›
        </button>
      </div>

      <div className="mollick-reviews__dots" aria-hidden="true">
        {reviews.map((item, index) => (
          <span
            key={item.id}
            className={index === active ? "is-active" : ""}
          />
        ))}
      </div>
    </section>
  );
}

export const ReviewsSection = memo(ReviewsSectionComponent);
